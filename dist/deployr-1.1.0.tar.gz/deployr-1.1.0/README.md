# Deployr

> **Deployr** is an interactive and scriptable CLI for managing [Wikimedia Toolforge](https://wikitech.wikimedia.org/wiki/Portal:Toolforge) tools.

[![PyPI version](https://badge.fury.io/py/deployr.svg)](https://badge.fury.io/py/deployr)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## Features

- 🔐 **SSH session management** — connect to the bastion or drop into a tool shell
- 🌐 **Webservice control** — start, stop, restart your Toolforge webservice
- 🚀 **Guided Flask deployment** — bundle, upload, venv-build, and restart in one command
- ⚙️ **Kubernetes jobs** — run, list, delete, and tail logs of Toolforge jobs
- 📁 **File uploads** — securely transfer files via the two-step SCP handshake
- 🔌 **SSH DB tunnels** — forward Wikimedia database ports to your local machine

---

## Installation

```bash
pip install deployr
```

**Prerequisites:**
- A [Wikitech](https://wikitech.wikimedia.org) developer account
- Your SSH public key registered in [Wikitech Preferences](https://wikitech.wikimedia.org/wiki/Special:Preferences)
- A registered Toolforge tool account

---

## Usage

### Interactive Console (default)
```bash
deployr
```

### Scriptable Subcommands

```bash
# SSH
deployr ssh                          # Connect to bastion
deployr shell                        # Switch to tool shell (become)

# Webservice
deployr webservice status
deployr webservice start --type python3.11
deployr webservice stop
deployr webservice restart
deployr webservice deploy app.py --python python3.11

# Kubernetes Jobs
deployr jobs list
deployr jobs run my-job "python3 script.py" --image python3.11
deployr jobs run daily-job "python3 report.py" --image python3.11 --schedule "0 0 * * *"
deployr jobs delete my-job
deployr jobs logs my-job              # stdout log
deployr jobs logs my-job --err        # stderr log

# File Transfer
deployr upload ./my-project .

# Database Tunnel
deployr tunnel --local-port 3306 --remote-host tools.db.svc.wikimedia.cloud

# Configuration
deployr configure
```

---

## First-Time Setup

On first run, Deployr will prompt you for:

| Field | Example |
|---|---|
| Wikimedia Username | `your-username` |
| Default Tool Name | `my-tool` *(without `tools.` prefix)* |
| Path to SSH Key | `~/.ssh/id_ed25519` |
| Bastion Host | `login.toolforge.org` |

Config is saved to `~/.toolforge_config.json`.

---

## Deploying a Flask App

```bash
deployr webservice deploy ./app.py --app-var app --python python3.11
```

This will:
1. Bundle your project (excluding `.git`, `.venv`, `__pycache__`)
2. Generate an `app.py` wrapper if your entry point is non-standard
3. SCP the bundle to remote staging
4. Launch a Kubernetes job to build the virtual environment
5. Install `requirements.txt` inside the Toolforge Python container
6. Restart the webservice

---

## License

MIT © Harikrishna T P
